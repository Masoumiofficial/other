@echo off
setlocal
cd /d "%~dp0"
set PORT=8000
where py >nul 2>nul
if not errorlevel 1 goto run_py
where python >nul 2>nul
if not errorlevel 1 goto run_python

echo Python was not found. Opening the static brand page directly instead.
start "" "%~dp0index.html"
echo You can still open index.html manually. If you need localhost, install Python 3 and run this file again.
pause
exit /b 0

:run_py
start "" "http://127.0.0.1:%PORT%/index.html"
py -m http.server %PORT% --bind 127.0.0.1
exit /b

:run_python
start "" "http://127.0.0.1:%PORT%/index.html"
python -m http.server %PORT% --bind 127.0.0.1
exit /b
