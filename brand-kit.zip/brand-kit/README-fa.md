# کیت هویت برند آهنگین

**نسخهٔ توسعه‌یافتهٔ مفهومی ۰٫۲ · ۵ اکتبر ۲۰۲۶**

این بسته، جهت هویت آهنگین را از معرفی اولیه به یک نظام کاربردی‌تر برای برند، محصول و شبکه‌های اجتماعی گسترش می‌دهد. جهت تصویری منتخب کاربر حفظ شده است. این نسخه برای بازبینی و نمونه‌سازی است؛ نام، حقوق محتوا، فونت و آماده‌بودن قابلیت‌ها تأیید حقوقی/محصولی نشده‌اند.

## شروع سریع

1. ZIP را Extract کنید.
2. برای دیدن پیش‌نمایش، `index.html` را باز کنید؛ یا با Python 3، روی `start-localhost.bat` دوبار کلیک کنید.
3. برای فهم وعده و لحن، `brand-book-fa.md` و `social-copy-fa.md` را بخوانید.
4. برای نمونه‌سازی رابط، `design-system-fa.md` و `assets/brand-tokens.css` را ببینید.
5. پیش از انتشار هر محتوا، `content-rights-checklist-fa.md` را مرور کنید.

## راهنمای فایل‌ها

### هویت و پیام

- `CHANGELOG-fa.md` — تفاوت‌های نسخهٔ ۰٫۲ و محدودیت‌های باقی‌مانده.
- `brand-book-fa.md` — جایگاه، وعده، مخاطب‌ها، لحن، هویت بصری، کاربرد و موارد باز.
- `social-copy-fa.md` — ستون‌های محتوا، بیو، معرفی، کپشن‌ها، CTA و پاسخ‌های کوتاه.
- `design-system-fa.md` — توکن‌ها، کامپوننت‌های دیجیتال، RTL و دسترس‌پذیری.
- `content-rights-checklist-fa.md` — چک‌لیست شناسنامه و نوع استفاده از هر اثر؛ راهنمای حقوقی نیست.
- `next-steps-fa.md` — تصمیم‌های گرفته‌شده و مواردی که هنوز باید مشخص شوند.

### پیش‌نمایش و اجرای محلی

- `index.html` — پیش‌نمایش بصری و مرور سریع هویت.
- `README-Windows-Localhost-fa.txt` — راهنمای ویندوز.
- `start-localhost.bat` — تلاش برای اجرای سرور Python در پورت ۸۰۰۰؛ در نبود Python فایل HTML را مستقیم باز می‌کند.

### فایل‌های گرافیکی

- `assets/ahangin-symbol-concept.png` — مرجع تصویری منتخب.
- `assets/ahangin-mark.svg`، `ahangin-logo-horizontal.svg`، `ahangin-logo-horizontal-reverse.svg`، `ahangin-logo-stacked.svg` — نسخه‌های برداری ساده‌شده.
- `assets/ahangin-mark-mono.svg` و `assets/favicon.svg` — نشان تک‌رنگ و آیکن مرورگر.
- `assets/app-icon-1024.png`, `instagram-avatar.png`, `telegram-avatar.png` — خروجی‌های PNG بر پایهٔ جهت منتخب.
- `assets/instagram-story-template.svg` — قالب استوری ۱۰۸۰×۱۹۲۰.
- `assets/social-post-template.svg` — قالب پست مربعی ۱۰۸۰×۱۰۸۰.
- `assets/artist-release-template.svg` — کارت معرفی اثر ۱۰۸۰×۱۳۵۰.
- `assets/playlist-cover-template.svg`, `assets/podcast-cover-template.svg` — قالب‌های مربعی قابل‌ویرایش.
- `assets/brand-wave-pattern.svg` — بافت موجی برای زمینه‌های گرافیکی.
- `assets/brand-tokens.css` و `assets/brand-tokens.json` — توکن‌های توسعه و طراحی.

### دادهٔ کاتالوگ

- `catalog/taxonomy-fa.csv` — دسته‌بندی محتوا، ژانر، حس‌وحال و پرچم‌های حقوقی.
- `catalog/priority-artists-seed.csv` — صف شروع تحقیق هنرمندها؛ هیچ ردیفی مجوزدار نیست.
- `catalog/track-intake-template.csv` — قالب ورود متادیتا و وضعیت حقوق هر محتوا.

## نکتهٔ نام و محتوا

«آهنگین» نام منتخب فعلی است، نه نام ثبت‌شده یا تأییدشده برای استفاده. نام و ریشه‌های مشابه باید در بازار هدف بررسی شوند. فایل هنرمندان فقط صف بررسی است. انتشار پخش، دانلود، ویدئو، پادکست، ریمیکس و تبلیغ هر اثر به اجازهٔ همان نوع استفاده وابسته است.

## نکتهٔ فنی و مجوز دارایی‌ها

SVGها در مرورگر، Figma، Illustrator و Inkscape قابل بازکردن‌اند. فونت در بسته جاسازی نشده؛ مجوز و نصب آن را جداگانه بررسی کنید. برای چاپ بزرگ، متن فارسی لوگو را در ابزار طراحی به مسیر تبدیل و خروجی را با طراح چاپ بررسی کنید.
